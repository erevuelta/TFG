function trafico_mezclado = mezclar_trafico(normal, ataque,separacion1)

separacion2=length(normal)-(separacion1+length(ataque));

zeros1=zeros(1,separacion1);
zeros2=zeros(1,separacion2);

traf_ataq_full = [zeros1 ataque(:,2)' zeros2];
traf_ataq_full = traf_ataq_full';
trafico_mezcla= normal(:,2) + traf_ataq_full;
trafico_mezclado=[normal(:,1) trafico_mezcla];

