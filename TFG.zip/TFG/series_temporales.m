function series_temporales(alfa, beta,delta,gam, alfaprim, betaprim, deltaprim,gamprim, mix_pre, attack, mix_post)
% G A M M A
figure;
plot(0:(length(gam)-1),gam, 'b')
hold on
plot(mix_pre, gamprim(mix_pre), 'c')
hold on
plot(attack, gamprim(attack), 'r')
hold on
plot(mix_post, gamprim(mix_post), 'c')
hold off
xlabel ('Segundos de la duraci�n de la trama')
ylabel('Valores gamma')
title('Gamma: Ventana de 5 minutos')
legend( 'normal', 'mixto', 'ataque')

% D E L T A
figure;
plot(0:(length(delta)-1),delta, 'b')
hold on
plot(mix_pre, deltaprim(mix_pre), 'c')
hold on
plot(attack, deltaprim(attack), 'r')
hold on
plot(mix_post, deltaprim(mix_post), 'c')
hold off
xlabel ('Segundos de la duraci�n de la trama')
ylabel('Valores delta')
title('Delta: Ventana de 5 minutos')
legend( 'normal', 'mixto', 'ataque')

% B E T A
figure;
plot(0:(length(beta)-1),beta, 'b')
hold on
plot(mix_pre, betaprim(mix_pre), 'c')
hold on
plot(attack, betaprim(attack), 'r')
hold on
plot(mix_post, betaprim(mix_post), 'c')
hold off
xlabel ('Segundos de la duraci�n de la trama')
ylabel('Valores beta')
title('Beta: Ventana de 5 minutos')
legend( 'normal', 'mixto', 'ataque')

% A L F A
figure;
plot(0:(length(alfa)-1),alfa, 'b')
hold on
plot(mix_pre, alfaprim(mix_pre), 'c')
hold on
plot(attack, alfaprim(attack), 'r')
hold on
plot(mix_post, alfaprim(mix_post), 'c')
hold off
xlabel ('Segundos de la duraci�n de la trama')
ylabel('Valores alfa')
title('Alfa: Ventana de 5 minutos')
legend( 'normal', 'mixto', 'ataque')