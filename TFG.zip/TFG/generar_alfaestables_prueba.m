function [alfaprim,deltaprim,gamprim,betaprim]=generar_alfaestables_prueba(traf_mezcla,tw0,tw1)

addpath('C:\Users\eduur\Documents\MATLAB\TFG\eric');
addpath('C:\Users\eduur\Documents\MATLAB\TFG\stbl-master');

dbstop if error;

ab2_pkt_mezclad_ddos_ord=traf_mezcla(tw0:tw1,1:2);

intervalo=1;


% ab2_pkt_mezclad_ddos_ord=traf_mezcla(tw0:tw1);

[alfaprim, betaprim, gamprim, deltaprim] = calculo_alfa_estable__valor_prueba(ab2_pkt_mezclad_ddos_ord, tw1, tw0, intervalo);


