function [C_norm,C_mixtpre,C_mixtpost,C_ataq,C_norm2,d_max_ataq]= centroids_comp(tw0,tw1,t0,t1,ncentroid_norm,ncentroid_mixtpre,ncentroid_mixtpost,ncentroid_ataq,type_dist,fin_trafico)
addpath('C:\Users\eduur\Documents\MATLAB\TFG\eric');
addpath('C:\Users\eduur\Documents\MATLAB\TFG\stbl-master');
dbstop if error;
load('ancho_banda_pkt2.txt')
load('ab_pkt2_ddos_puro.txt')

alfa_norm=[];
delta_norm=[];
gam_norm=[];
beta_norm=[];

alfa_mixt=[];
delta_mixt=[];
gam_mixt=[];
beta_mixt=[];

alfa_ataq=[];
delta_ataq=[];
gam_ataq=[];
beta_ataq=[];

alfa_mixt2=[];
delta_mixt2=[];
gam_mixt2=[];
beta_mixt2=[]; 

alfa_norm2=[];
delta_norm2=[];
gam_norm2=[];
beta_norm2=[];

d_norm=[];
d_mixtpost=[];
d_mixtpre=[];
d_ataq=[];
d=[];

clase={};
class_true={};
inc=1;

comienzo_trafico=round(fin_trafico-(605181/10)+1);
cacho_trafico_normal=[comienzo_trafico:fin_trafico];
if t0>=comienzo_trafico && t0<=fin_trafico
    t0=round((t0/length(ancho_banda_pkt2))*(length(cacho_trafico_normal/comienzo_trafico)));
    t1=2169+t0; 
    traf_mezcla=mezclar_trafico(ancho_banda_pkt2(cacho_trafico_normal,:),ab_pkt2_ddos_puro,t0);
    else
    traf_mezcla=ancho_banda_pkt2(cacho_trafico_normal,:);
end


for tw0=1:inc:((605181/10)-(tw1-tw0+1)) 
    signal=traf_mezcla(tw0:tw1,1:2);
if (tw0 < t0) && (tw1 <= t0)
    
    [alfaprim, betaprim, gamprim, deltaprim ] = parametrizacion_calculo_alfa_estables_prueba(signal);
    alfa_norm=[alfa_norm alfaprim];
    delta_norm=[delta_norm deltaprim];
    gam_norm=[gam_norm gamprim];
    beta_norm=[beta_norm betaprim];
    
    class_true{tw0}='normal';
    
elseif (tw0 < t0) && (tw1 > t0) && (tw1< t1)
    
   [alfaprim, betaprim, gamprim, deltaprim ] = parametrizacion_calculo_alfa_estables_prueba(signal);
    alfa_mixt=[alfa_mixt alfaprim];
    delta_mixt=[delta_mixt deltaprim];
    gam_mixt=[gam_mixt gamprim];
    beta_mixt=[beta_mixt betaprim];
    
    class_true{tw0}='mixtopre';
    
elseif  (tw0 >= t0) && (tw1 <= t1)
    
    [alfaprim, betaprim, gamprim, deltaprim ] = parametrizacion_calculo_alfa_estables_prueba(signal);
    alfa_ataq=[alfa_ataq alfaprim];
    delta_ataq=[delta_ataq deltaprim];
    gam_ataq=[gam_ataq gamprim];
    beta_ataq=[beta_ataq betaprim];
    
    class_true{tw0}='ataque';
    
elseif (tw0 > t0) && (tw0 < t1) && (tw1> t1)
    
    [alfaprim, betaprim, gamprim, deltaprim ] = parametrizacion_calculo_alfa_estables_prueba(signal);
    alfa_mixt2=[alfa_mixt2 alfaprim];
    delta_mixt2=[delta_mixt2 deltaprim];
    gam_mixt2=[gam_mixt2 gamprim];
    beta_mixt2=[beta_mixt2 betaprim];
    
    class_true{tw0}='mixtopost';
    
elseif (tw0 >= t1) && (tw1 > t1)&& (tw1<605181+inc)

    [alfaprim, betaprim, gamprim, deltaprim ] = parametrizacion_calculo_alfa_estables_prueba(signal);
    alfa_norm2=[alfa_norm2 alfaprim];
    delta_norm2=[delta_norm2 deltaprim];
    gam_norm2=[gam_norm2 gamprim];
    beta_norm2=[beta_norm2 betaprim];
    
    class_true{tw0}='normal';
end

tw1=tw1+inc;
end  
beta_all=[beta_norm  beta_mixt beta_ataq beta_mixt2 beta_norm2]';

datos_norm=[alfa_norm ; delta_norm ; gam_norm; beta_norm]';


datos_mixtpre=[alfa_mixt; delta_mixt; gam_mixt; beta_mixt]';


datos_mixtpost=[alfa_mixt2; delta_mixt2; gam_mixt2; beta_mixt2]';


datos_ataq=[alfa_ataq; delta_ataq; gam_ataq; beta_ataq]';


datos_norm2=[alfa_norm2 ; delta_norm2 ; gam_norm2; beta_norm2]';


datos_all=[alfa_norm alfa_mixt alfa_ataq alfa_mixt2 alfa_norm2 ; delta_norm delta_mixt delta_ataq delta_mixt2 delta_norm2 ; gam_norm gam_mixt gam_ataq gam_mixt2 gam_norm2; beta_norm beta_mixt beta_ataq beta_mixt2 beta_norm2]';

[idx_norm,C_norm]=kmeans(datos_norm(:,[1 2 3]),ncentroid_norm);
if isempty(datos_mixtpre)==0
[idx_mixtpre,C_mixtpre]=kmeans(datos_mixtpre(:,[1 2 3]),ncentroid_mixtpre);
    else   
    C_mixtpre=0;
end
if isempty(datos_mixtpost)==0
[idx_mixtpost,C_mixtpost]=kmeans(datos_mixtpost(:,[1 2 3]),ncentroid_mixtpost);
    else   
    C_mixtpost=0;
end
if isempty(datos_ataq)==0
[idx_ataq,C_ataq]=kmeans(datos_ataq(:,[1 2 3]),ncentroid_ataq);
    else   
    C_ataq=0;
end
if isempty(datos_norm2)==0
[idx_norm2,C_norm2]=kmeans(datos_norm2(:,[1 2 3]),ncentroid_norm);
     else   
    C_norm2=0;
end

figure;
for c=1:ncentroid_norm
    
    scatter3(C_norm(c,1),C_norm(c,2),C_norm(c,3),50,'go')
    hold on;
end
% for c=1:ncentroid_mixtpre
%     hold on
%     scatter3(C_mixtpre(c,1),C_mixtpre(c,2),C_mixtpre(c,3),300,'kx','LineWidth',3)
% end
% for c=1:ncentroid_mixtpost
%     hold on
%     scatter3(C_mixtpost(c,1),C_mixtpost(c,2),C_mixtpost(c,3),300,'kx','LineWidth',3)
% end
if isempty(datos_mixtpre)==0
for c=1:ncentroid_ataq
    
    scatter3(C_ataq(c,1),C_ataq(c,2),C_ataq(c,3),50,'ro')
    hold on;
end
end
hold off

xlabel('alfa');
ylabel('delta');
zlabel('gamma');
title('Tr�fico Total y Centroides');






