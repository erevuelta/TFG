function clusterizacion (alfaprim, betaprim, deltaprim, gamprim, normpre, normmixt,mixtataq,ataqmixt,mixtnorm, normpost)

clasificador=[ones(1,(normmixt-normpre)) (ones(1,(mixtataq-normmixt))+1) (ones(1, (ataqmixt-mixtataq))+2) (ones(1,(mixtnorm-ataqmixt))+3) (ones(1,(normpost-mixtnorm))+4)]';
datos= [alfaprim(normpre:(normpost-1)); deltaprim(normpre:(normpost-1)); gamprim(normpre:(normpost-1)); betaprim(normpre:(normpost-1))]';

clase={};
for i=1:size(datos,1)
    if i<(normmixt-normpre)+1
        clase{i}='normalpre';
    elseif i<((mixtataq-normmixt)+(normmixt-normpre)+1)
        clase{i}='mixtopre';
    elseif i<((mixtataq-normmixt)+(normmixt-normpre)+(ataqmixt-mixtataq)+1)
        clase{i}='ataque';
    elseif i<((mixtataq-normmixt)+(normmixt-normpre)+(ataqmixt-mixtataq)+(mixtnorm-ataqmixt)+1)
        clase{i}='mixtopost';
    else
        clase{i}='normalpost';
    end
end
clase=clase';

% ALFA DELTA
[x,y] = meshgrid(1.3:0.01:2, 90000:100:100000);
x = x(:);
y = y(:);
[C_ad,err,P,logp,coeff] = classify([x y],datos(:,1:2),clasificador, 'quadratic');

figure;
gscatter(x,y,C_ad,'byryb');
hold on
gscatter(datos(:,1), datos(:,2), clase, 'byryb', 'o+oxo');
xlabel('alfa');
ylabel('delta');
title('An�lisis Cuadr�tico Discriminante');
hold off

%DELTA GAMMA
[x,y] = meshgrid(3000:100:6000,90000:100:100000);
x = x(:);
y = y(:);
[C_dg,err,P,logp,coeff] = classify([x y],datos(:,2:3),clasificador, 'quadratic');

figure;
gscatter(x,y,C_dg,'byryb');
hold on
gscatter(datos(:,3), datos(:,2), clase, 'byryb', 'o+oxo');
xlabel('gamma');
ylabel('delta');
title('An�lisis Cuadr�tico Discriminante');
hold off

%ALFA GAMMA
[x,y] = meshgrid(1.3:0.01:2, 2500:100:6000);
x = x(:);
y = y(:);
[C_ag,err,P,logp,coeff] = classify([x y],datos(:,[1 3]),clasificador, 'quadratic');

figure;
gscatter(x,y,C_ag,'byryb');
hold on
gscatter(datos(:,1), datos(:,3), clase, 'byryb', 'o+oxo');
xlabel('alfa');
ylabel('gamma');
title('An�lisis Cuadr�tico Discriminante');
hold off

%ALFA GAMMA DELTA
[x,y,z]= meshgrid(1.3:0.01:2, 90000:100:100000 ,2500:100:6000);
x=x(:);
y=y(:);
z=z(:);
[C_agd,err,P,logp,coeff] = classify([x y z],datos(:,[1 2 3]),clasificador, 'quadratic');
colors = 'rgb';
markers = 'osd';
[~,~,id] = unique(clase);
figure;
for idx = 1 : 3
    data = datos(id == idx,:);
    plot3(data(:,1), data(:,2), data(:,3), [colors(idx) markers(idx)]);
    hold on;
end
xlabel('alfa');
ylabel('delta');
zlabel('gamma');
title('An�lisis Cuadr�tico Discriminante');
hold off

%MATRICES DE CONFUSION

q_ad = fitcdiscr(datos(:,1:2),clase,'DiscrimType','quadratic');
predict = resubPredict(q_ad);
figure;
MatrizAlfaDelta = confusionchart(clase,predict, 'RowSummary','row-normalized','ColumnSummary','column-normalized');
title('Matriz de confusion Alfa-Delta');

q_dg = fitcdiscr(datos(:,2:3),clase,'DiscrimType','quadratic');
predict = resubPredict(q_dg);
figure;
MatrizDeltaGamma = confusionchart(clase,predict, 'RowSummary','row-normalized','ColumnSummary','column-normalized');
title('Matriz de confusion Delta-Gamma');

q_ag = fitcdiscr(datos(:,[1 3]),clase,'DiscrimType','quadratic');
predict= resubPredict(q_ag);
figure;
MatrizAlfaGamma = confusionchart(clase,predict, 'RowSummary','row-normalized','ColumnSummary','column-normalized');
title('Matriz de confusion Alfa-Gamma');

q_adg = fitcdiscr(datos(:,[1 2 3]),clase,'DiscrimType','quadratic');
predict3= resubPredict(q_adg);
figure;
MatrizAlfaGammaDelta = confusionchart(clase,predict3, 'RowSummary','row-normalized','ColumnSummary','column-normalized');
title('Matriz de confusion Alfa-Gamma-Delta');





















