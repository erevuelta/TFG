function [C_norm,C_mixtpre,C_mixtpost,C_ataq,C_norm2,d_max_ataq]= centroids(tw0,tw1,t0,t1,ncentroid_norm,ncentroid_mixtpre,ncentroid_mixtpost,ncentroid_ataq,type_dist,fin_trafico)
addpath('C:\Users\eduur\Documents\MATLAB\TFG\eric');
addpath('C:\Users\eduur\Documents\MATLAB\TFG\stbl-master');
dbstop if error;
load('ancho_banda_pkt2.txt')
load('ab_pkt2_ddos_puro.txt')

alfa_norm=[];
delta_norm=[];
gam_norm=[];
beta_norm=[];

alfa_mixt=[];
delta_mixt=[];
gam_mixt=[];
beta_mixt=[];

alfa_ataq=[];
delta_ataq=[];
gam_ataq=[];
beta_ataq=[];

alfa_mixt2=[];
delta_mixt2=[];
gam_mixt2=[];
beta_mixt2=[]; 

alfa_norm2=[];
delta_norm2=[];
gam_norm2=[];
beta_norm2=[];

d_norm=[];
d_mixtpost=[];
d_mixtpre=[];
d_ataq=[];
d=[];

clase={};
class_true={};
inc=1;

comienzo_trafico=round(fin_trafico-(605181/10)+1);
cacho_trafico_normal=[comienzo_trafico:fin_trafico];
traf_mezcla=mezclar_trafico(ancho_banda_pkt2(cacho_trafico_normal,:),ab_pkt2_ddos_puro,t0);

for tw0=1:inc:((605181/10)-(tw1-tw0+1)) 
    signal=traf_mezcla(tw0:tw1,1:2);
if (tw0 < t0) && (tw1 <= t0)
    
    [alfaprim, betaprim, gamprim, deltaprim ] = parametrizacion_calculo_alfa_estables_prueba(signal);
    alfa_norm=[alfa_norm alfaprim];
    delta_norm=[delta_norm deltaprim];
    gam_norm=[gam_norm gamprim];
    beta_norm=[beta_norm betaprim];
    
    class_true{tw0}='normal';
    
elseif (tw0 < t0) && (tw1 > t0) && (tw1< t1)
    
   [alfaprim, betaprim, gamprim, deltaprim ] = parametrizacion_calculo_alfa_estables_prueba(signal);
    alfa_mixt=[alfa_mixt alfaprim];
    delta_mixt=[delta_mixt deltaprim];
    gam_mixt=[gam_mixt gamprim];
    beta_mixt=[beta_mixt betaprim];
    
    class_true{tw0}='mixtopre';
    
elseif  (tw0 >= t0) && (tw1 <= t1)
    
    [alfaprim, betaprim, gamprim, deltaprim ] = parametrizacion_calculo_alfa_estables_prueba(signal);
    alfa_ataq=[alfa_ataq alfaprim];
    delta_ataq=[delta_ataq deltaprim];
    gam_ataq=[gam_ataq gamprim];
    beta_ataq=[beta_ataq betaprim];
    
    class_true{tw0}='ataque';
    
elseif (tw0 > t0) && (tw0 < t1) && (tw1> t1)
    
    [alfaprim, betaprim, gamprim, deltaprim ] = parametrizacion_calculo_alfa_estables_prueba(signal);
    alfa_mixt2=[alfa_mixt2 alfaprim];
    delta_mixt2=[delta_mixt2 deltaprim];
    gam_mixt2=[gam_mixt2 gamprim];
    beta_mixt2=[beta_mixt2 betaprim];
    
    class_true{tw0}='mixtopost';
    
elseif (tw0 >= t1) && (tw1 > t1)&& (tw1<605181+inc)

    [alfaprim, betaprim, gamprim, deltaprim ] = parametrizacion_calculo_alfa_estables_prueba(signal);
    alfa_norm2=[alfa_norm2 alfaprim];
    delta_norm2=[delta_norm2 deltaprim];
    gam_norm2=[gam_norm2 gamprim];
    beta_norm2=[beta_norm2 betaprim];
    
    class_true{tw0}='normal';
end

tw1=tw1+inc;
end  
beta_all=[beta_norm  beta_mixt beta_ataq beta_mixt2 beta_norm2]';

datos_norm=[alfa_norm ; delta_norm ; gam_norm; beta_norm]';


datos_mixtpre=[alfa_mixt; delta_mixt; gam_mixt; beta_mixt]';


datos_mixtpost=[alfa_mixt2; delta_mixt2; gam_mixt2; beta_mixt2]';


datos_ataq=[alfa_ataq; delta_ataq; gam_ataq; beta_ataq]';


datos_norm2=[alfa_norm2 ; delta_norm2 ; gam_norm2; beta_norm2]';


datos_all=[alfa_norm alfa_mixt alfa_ataq alfa_mixt2 alfa_norm2 ; delta_norm delta_mixt delta_ataq delta_mixt2 delta_norm2 ; gam_norm gam_mixt gam_ataq gam_mixt2 gam_norm2; beta_norm beta_mixt beta_ataq beta_mixt2 beta_norm2]';

[idx_norm,C_norm]=kmeans(datos_norm(:,[1 2 3]),ncentroid_norm);
[idx_mixtpre,C_mixtpre]=kmeans(datos_mixtpre(:,[1 2 3]),ncentroid_mixtpre);
[idx_mixtpost,C_mixtpost]=kmeans(datos_mixtpost(:,[1 2 3]),ncentroid_mixtpost);
[idx_ataq,C_ataq]=kmeans(datos_ataq(:,[1 2 3]),ncentroid_ataq);
[idx_norm2,C_norm2]=kmeans(datos_norm2(:,[1 2 3]),ncentroid_norm);



% idx_all=[idx_norm' idx_mixtpre' idx_ataq' idx_mixtpost' idx_norm2']';
% 
%    
% d_norm= pdist2(datos_all(:,[1 2 3]),C_norm,type_dist);
% d_mixtpre= pdist2(datos_all(:,[1 2 3]),C_mixtpre,type_dist);
% d_mixtpost= pdist2(datos_all(:,[1 2 3]),C_mixtpost,type_dist);
% d_ataq= pdist2(datos_all(:,[1 2 3]),C_ataq,type_dist);
% d_norm2=pdist2(datos_all(:,[1 2 3]),C_norm2,type_dist);
% 
% interval_ataq=[(length(idx_norm)+length(idx_mixtpre)):(length(idx_norm)+length(idx_mixtpre)+length(idx_ataq)-1)];
% interval_mixtpre=[(length(idx_norm)):(length(idx_norm)+length(idx_mixtpre)-1)];
% interval_mixtpost=[(length(idx_norm)+length(idx_mixtpre)+length(idx_ataq)):(length(idx_norm)+length(idx_mixtpre)+length(idx_ataq)+length(idx_mixtpost)-1)];
% 
% d_max_ataq=max(d_ataq(interval_ataq,:));
% d_max_mixtpre=max(d_mixtpre(interval_mixtpre,:));
% d_max_mixtpost=max(d_mixtpost(interval_mixtpost,:));




% for k=1:length(datos_all(:,1))
%         
% 
%     dmin_norm=min(d_norm(k,:));
%     dmin_mixtpre=min(d_mixtpre(k,:));
%     dmin_mixtpost=min(d_mixtpost(k,:));
%     dmin_ataq=min(d_ataq(k,:));
%     dmin_norm2=min(d_norm2(k,:));
%     
%     if dmin_norm<=dmin_mixtpre && dmin_norm<=dmin_mixtpost && dmin_norm<=dmin_ataq
%         
%         clase{k}='normal';
%     
%     elseif dmin_norm2<=dmin_mixtpre && dmin_norm2<=dmin_mixtpost && dmin_norm2<=dmin_ataq
%         
%         clase{k}='normal';
%     
%     elseif dmin_mixtpre<=dmin_norm && dmin_mixtpre<=dmin_mixtpost && dmin_mixtpre<=dmin_ataq && dmin_mixtpre<=dmin_norm2
%        
%         clase{k}='normal';
%         i=idx_all(k,:);
% %         if k>=interval_mixtpre(1) && k<=interval_mixtpre(length(interval_mixtpre))
%          if i<=ncentroid_mixtpre
%            if dmin_mixtpre == d_mixtpre(k,i)
%              if dmin_mixtpre <= d_max_mixtpre(:,i)
%             
%                  clase{k}='mixtopre';
%              end
%            end
%          end
%         
%     elseif dmin_mixtpost<=dmin_norm && dmin_mixtpost<=dmin_mixtpre && dmin_mixtpost<=dmin_ataq && dmin_mixtpost<=dmin_norm2
%         
%         clase{k}='normal';
%         
%          i=idx_all(k,:);
%         if i<=ncentroid_mixtpost
%          if dmin_mixtpost == d_mixtpost(k,i)
% %         if k>=interval_mixtpost(1) && k<=interval_mixtpost(length(interval_mixtpost))
%               if dmin_mixtpost <= d_max_mixtpost(:,i)
%             
%                      clase{k}='mixtopost'; 
%               end
%          end
%         end
%         
%         
%     elseif dmin_ataq<=dmin_norm && dmin_ataq<=dmin_mixtpost && dmin_ataq<=dmin_mixtpre && dmin_ataq<=dmin_norm2
%         
% %         clase{k}='normal';
% %         i=idx_all(k,:);
% %         if i<=ncentroid_ataq
% %              if dmin_ataq <= d_max_ataq(:,i)
% %             
% %                  clase{k}='ataque';
%         clase{k}='normal';
%          
% %         if k>=interval_ataq(1) && k<=interval_ataq(length(interval_ataq))
%              i=idx_all(k,:);
%            if i<=ncentroid_ataq
%             if dmin_ataq == d_ataq(k,i)
%              if dmin_ataq <= d_max_ataq(:,i)
%             
%                  clase{k}='ataque';
%              end
%             end
%           end
%         
%     end
%     
% end
% clase=clase';
% class_true=class_true';
% 
% 
% % figure;
% % subplot(2,2,1)
% % silhouette(datos_norm(:,[1 2 3]), idx_norm)
% % title(' Analisis Numero de Clusters: Trafico Normal')
% % subplot(2,2,2)
% % silhouette(datos_mixtpre(:,[1 2 3]), idx_mixtpre)
% % title(' Analisis Numero de Clusters: Trafico Mixto-pre')
% % subplot(2,2,3)
% % silhouette(datos_mixtpost(:,[1 2 3]), idx_mixtpost)
% % title(' Analisis Numero de Clusters: Trafico Mixto-post')
% % subplot(2,2,4)
% % silhouette(datos_ataq(:,[1 2 3]), idx_ataq)
% % title(' Analisis Numero de Clusters: Trafico Ataque')
% 
% 
% %Representacion tr�fico: normal, mixto y ataque
% N O R M A L

% C = repmat([0,1,0],numel(datos_norm(:,1)),1);
% figure;
% scatter3(datos_norm(:,1), datos_norm(:,2), datos_norm(:,3),50,C);
% for c=1:ncentroid_norm
%     hold on
%     scatter3(C_norm(c,1),C_norm(c,2),C_norm(c,3),300,'kx','LineWidth',3)
% end
% 
% hold off
% xlabel('alfa');
% ylabel('delta');
% zlabel('gamma');
% title('Tr�fico Normal');
% 
% % % M I X T O
% 
% C1 = repmat([0,0,1],numel(datos_mixtpre(:,1)),1);
% C3 = repmat([0,1,1],numel(datos_mixtpost(:,1)),1);
% figure;
% scatter3(datos_mixtpre(:,1), datos_mixtpre(:,2), datos_mixtpre(:,3),50,C1);
% hold on
% scatter3(datos_mixtpost(:,1), datos_mixtpost(:,2), datos_mixtpost(:,3),50,C3);
% for c=1:ncentroid_mixtpre
%     hold on
%     scatter3(C_mixtpre(c,1),C_mixtpre(c,2),C_mixtpre(c,3),200,'kx','LineWidth',3)
% end
% for c=1:ncentroid_mixtpost
%     hold on
%     scatter3(C_mixtpost(c,1),C_mixtpost(c,2),C_mixtpost(c,3),200,'rx','LineWidth',3)
% end
% hold off
% xlabel('alfa');
% ylabel('delta');
% zlabel('gamma');
% title('Tr�fico Mixto');
% 
% %  A T A Q U E 

% C2 = repmat([1,0,0],numel(datos_ataq(:,1)),1);
% figure;
% scatter3(datos_ataq(:,1), datos_ataq(:,2), datos_ataq(:,3),50,C2);
% for c=1:ncentroid_ataq
%     hold on
%     scatter3(C_ataq(c,1),C_ataq(c,2),C_ataq(c,3),200,'kx','LineWidth',3)    
% end
% hold off
% xlabel('alfa');
% ylabel('delta');
% zlabel('gamma');
% title('Tr�fico Ataque');
% 
% figure;
% scatter3(datos_ataq(:,1), datos_ataq(:,2), datos_ataq(:,3),20,'r.');
% hold on
% scatter3(datos_mixtpre(:,1), datos_mixtpre(:,2), datos_mixtpre(:,3),20,'bo');
% hold on
% scatter3(datos_mixtpost(:,1), datos_mixtpost(:,2), datos_mixtpost(:,3),20,'co');
% % hold on
% % scatter3(datos_norm(:,1), datos_norm(:,2), datos_norm(:,3),20,'g.');
% 
% for c=1:ncentroid_norm
%     hold on
%     scatter3(C_norm(c,1),C_norm(c,2),C_norm(c,3),300,'ko','LineWidth',3)
% end
% for c=1:ncentroid_mixtpre
%     hold on
%     scatter3(C_mixtpre(c,1),C_mixtpre(c,2),C_mixtpre(c,3),300,'kx','LineWidth',3)
% end
% for c=1:ncentroid_mixtpost
%     hold on
%     scatter3(C_mixtpost(c,1),C_mixtpost(c,2),C_mixtpost(c,3),300,'kx','LineWidth',3)
% end
% for c=1:ncentroid_ataq
%     hold on
%     scatter3(C_ataq(c,1),C_ataq(c,2),C_ataq(c,3),300,'kx','LineWidth',3)    
% end
% 
% hold off
% 
% xlabel('alfa');
% ylabel('delta');
% zlabel('gamma');
% title('Tr�fico Total y Centroides');
% 
% xname=char('alfa','delta ');
% yname=char('gamma','beta');
% 
% % figure;
% % uniqueGroups = unique(clase);
% % colors = 'rgb';
% % markers = 'osd';
% % 
% % scatter3(datos_all(:,1),datos_all(:,2),datos_all(:,3),20,colors,markers)
% 
% % gplotmatrix(datos_all(:,1:2),datos_all(:,3:4),clase,[],'.',[],'on','',xname,yname);
% 
% % 
% % q_adg = fitcdiscr(datos_all(:,[1 2 3]),clase,'DiscrimType','Quadratic');
% % predict3= resubPredict(q_adg);
% 
% 
% figure;
% MatrizAlfaGammaDelta = confusionchart(class_true,clase, 'RowSummary','row-normalized','ColumnSummary','column-normalized');
% title('Matriz de confusion Alfa-Gamma-Delta quadratic');
% 
% error=datos_ataq(4,2891239392,1122);
%  
% end
