function [alpha,beta,gam,delta]=parametrizacion_calculo_alfa_estables(signal, duracion_ventana, segundo_inicio, x,graficas,tipo_dato,color)
%Esta funcion se encarga de calcular los valores de los alfa estable y de
%representarlos respecto de la se�al y de la ventana que se le pase como
%argumento. Representa la se�al que va a ser calculada, los valores de los alfa estable y el histograma de la sekal normalizada (pdf)
%.Signal es la se�al de la cual se va a calcular los valores de alfa-estable, es necesario que
%sea de dos dimensiones donde uno sea el eje que sigue y otro la variable aleatoria. La duracion de ventana se da en
%minutos y se realiza la conversion a segundos.X es el rango de valores que va a tener la representacion
%de los alfa estable
if duracion_ventana < 1
    sprintf('El valor seleccionado de la duracion de ventana es peque�o\n')
return;
end
 
duracion_ventana=duracion_ventana*60; %en segundos
% duracion_ventana=duracion_ventana*60/2;


params = stblfit(signal(segundo_inicio:duracion_ventana+segundo_inicio,2),'percentile','Display');
% params = stblfit(signal(segundo_inicio+60:duracion_ventana+60+segundo_inicio,2),'percentile','Display');


% params = stblfit(signal(segundo_inicio-duracion_ventana:duracion_ventana+segundo_inicio,2),'percentile','Display');
% params = stblfit(signal(segundo_inicio-duracion_ventana+60:duracion_ventana+60+segundo_inicio,2),'percentile','Display');

eje=(0:duracion_ventana);
alpha= params(1,1);
beta = params(2,1);
gam = params(3,1);
delta =params(4,1);
if graficas==1

    figure
    plot (eje,signal(segundo_inicio:duracion_ventana+segundo_inicio,2));
%     plot (signal(segundo_inicio+60:duracion_ventana+60+segundo_inicio,1),signal(segundo_inicio+60:duracion_ventana+60+segundo_inicio,2));


%     plot (signal(segundo_inicio-duracion_ventana:duracion_ventana+segundo_inicio,1),signal(segundo_inicio-duracion_ventana:duracion_ventana+segundo_inicio,2));
%     plot (signal(segundo_inicio-duracion_ventana+60:duracion_ventana+60+segundo_inicio,1),signal(segundo_inicio-duracion_ventana+60:duracion_ventana+60+segundo_inicio,2));

    title('Representacion del valor de la se�al donde se ha seleccionado la ventana');
    xlabel('Tiempo en segundo de la ventana')
    ylabel(sprintf('%s por segundo',tipo_dato));

    vector=stblpdf(x,alpha,beta,gam,delta,'quick');
    figure
    plot( x , vector)

%     plot( x , stblpdf(x,alpha,beta,gam,delta))

    title(sprintf('Representacion alfa estable alfa = %d, beta = %d, gamma= %d, delta = %d \n vs Histograma pdf',alpha,beta,gam,delta))
    hold on;

    histogram(signal(segundo_inicio:duracion_ventana+segundo_inicio,2),'Normalization','pdf','EdgeColor',color,'FaceColor',color);

%     histogram(signal(segundo_inicio+60:duracion_ventana+60+segundo_inicio,2),'Normalization','pdf')


%     histogram(signal(segundo_inicio-duracion_ventana:duracion_ventana+segundo_inicio,2),'Normalization','pdf')
%     histograrm(signal(segundo_inicio-duracion_ventana+60:duracion_ventana+60+segundo_inicio,2),'Normalization','pdf')


end


end

