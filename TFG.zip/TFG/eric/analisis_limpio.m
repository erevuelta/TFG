%Lectura de ficheros
clc;
clear all;
close all;

addpath('C:\Users\usuario\Documents\UAM Teleco\4� Teleco\TFG\TFG eric\stbl-master');


%% lectura de los ficheros normales (segundos | paquetes)

load('ancho_banda_pkt2.txt')

% lectura de los ficheros anomalos puros (segundos | paquetes)

load('ab_pkt2_ddos_puro.txt')



%Lectura de los parametros
% load('alfa_15min.mat')
% load('beta_15min.mat')
% load('gam_15min.mat')
% load('delta_15min.mat')
% 
% load('alfaprim_15min.mat')
% load('betaprim_15min.mat')
% load('gamprim_15min.mat')
% load('deltaprim_15min.mat')


%% ancho de banda normal
% figure(1)
% eje=(0:length(ancho_banda_bits2(:,1))-1);
% plot(eje,ancho_banda_bits2(:,2))
% title('Bits por segundo')
% xlabel('Tiempo unix de la conexion')
% ylabel('Bits');
% 
% figure(2)
% eje=(0:length(ancho_banda_pkt2(:,1))-1);
% plot(eje,ancho_banda_pkt2(:,2))
% title('Paquetes por segundo')
% xlabel('Tiempo unix de la conexion')
% ylabel('Paquetes');

%% ancho de banda ddos
% figure(3)
% eje=(0:length(ab_bits2_ddos_puro(:,1))-1);
% plot(eje,ab_bits2_ddos_puro(:,2))
% title('Bits por segundo ddos ataque')
% xlabel('Tiempo unix de la conexion')
% ylabel('Bits');
% 
% figure(4)
% eje=(0:length(ab_pkt2_ddos_puro(:,1))-1);
% plot(eje,ab_pkt2_ddos_puro(:,2))
% title('Paquetes por segundo ddos ataque')
% xlabel('tiempo unix de la conexion')
% ylabel('Paquetes ');
% 
% figure(5)
% eje=(0:length(ab2_bits_mezclad_ddos_ord(:,1))-1);
% plot(eje,ab2_bits_mezclad_ddos_ord(:,2))
% title('Bits por segundo ddos mezclado')
% xlabel('tiempo unix de la conexion')
% ylabel('Bits ');
% 
% figure(6)
% plot(eje,ab2_pkt_mezclad_ddos_ord(:,2))
% title('Paquetes por segundo ddos mezclado')
% xlabel('tiempo unix de la conexion')
% ylabel('Paquetes');


ddos_time=[1470645281 1470740960 1470741065];


seg_ddos= find(ddos_time(3) == ab2_pkt_mezclad_ddos_ord(:,1));

x = 200e6:10000:1000e+6;
x2=2e4:100:20e4;

num_valor=300;

graficas=0;
tam=length(ancho_banda_bits2);
valores=[]; %posiciones de maximos se tienen que pasar a valores de tiempo para buscar en el tr�fico mezlcado
valores_m=[];

valores(1)=find( 1960==ab_pkt2_ddos_puro(:,2));
valores(2)=find( 2092==ab_pkt2_ddos_puro(:,2));
valores(3)=find(max(ab_pkt2_ddos_puro(:,2))==ab_pkt2_ddos_puro(:,2));

valores_m(1)=find(ab_pkt2_ddos_puro(valores(1),1) ==ab2_pkt_mezclad_ddos_ord(:,1));
valores_m(2)=find(ab_pkt2_ddos_puro(valores(2),1) ==ab2_pkt_mezclad_ddos_ord(:,1));
valores_m(3)=find(ab_pkt2_ddos_puro(valores(3),1) ==ab2_pkt_mezclad_ddos_ord(:,1));

%close all;
%% ddos

% por bits
% parametrizacion_calculo_alfa_estables(ancho_banda_bits2, duracion, seg_ddos, x,graficas,'Bits','r');
% parametrizacion_calculo_alfa_estables(ab2_bits_mezclad_ddos_ord, duracion, seg_ddos, x ,graficas,'Bits','k');
% 
% % por pkt
% 
% parametrizacion_calculo_alfa_estables(ancho_banda_pkt2, 7, valores_m(3), x2,graficas,'Paquetes','r' );
% parametrizacion_calculo_alfa_estables(ab2_pkt_mezclad_ddos_ord, 7, valores_m(3), x2,graficas,'Paquetes','k' );


%% pkt
separacion=3600*2;
intervalo=1;
duracion=10;
len=length(ab_pkt2_ddos_puro(:,2));
v=find(max(ab_pkt2_ddos_puro(:,2))==ab_pkt2_ddos_puro(:,2));
array_15_ddos_puro=zeros(1,15*60);
for i=1:(len-v)
    array_15_ddos_puro(i)=ab_pkt2_ddos_puro(i+v-1,2);
end
%gamma es sigma y delta es mu
[alfa, beta, gam, delta ] = calculo_alfa_estable__valor(ancho_banda_pkt2, duracion,graficas,x2, 'Paquetes','b', valores_m(3), intervalo, separacion,separacion);

[alfaprim, betaprim, gamprim, deltaprim ] = calculo_alfa_estable__valor(ab2_pkt_mezclad_ddos_ord, duracion,graficas,x2, 'Paquetes','r', valores_m(3), intervalo, separacion,separacion);

save('alfa_10min.mat','alfa')
save('beta_10min.mat','beta')
save('gam_10min.mat','gam')
save('delta_10min.mat','delta')

save('alfaprim_10min.mat','alfaprim')
save('betaprim_10min.mat','betaprim')
save('gamprim_10min.mat','gamprim')
save('deltaprim_10min.mat','deltaprim')

%representacion_valores_comparativa(alfa, beta, gam, delta, alfaprim, betaprim, gamprim, deltaprim);

%Representacion de parametros frente a otros parametros
%representacion_parametros (alfa, beta, gam, delta, alfaprim, betaprim, gamprim, deltaprim)
%Hacerlo para ventanas de 10min y de 5min
%Hacer la 

%% bits

val=find(max(ab_bits2_ddos_puro(:,2))==ab_bits2_ddos_puro(:,2));

val_m=find(ab_bits2_ddos_puro(val,1) ==ab2_bits_mezclad_ddos_ord(:,1));

separacion=3600*2; % 2 horas
intervalo=1;
duracion=15;
graficas=0;
% [media] =  calculo_media(ancho_banda_pkt2, duracion, val_m, intervalo, separacion,separacion );
% 
% [mediaprim] = calculo_media(ab2_pkt_mezclad_ddos_ord, duracion, val_m, intervalo, separacion,separacion );
% 
% 
% figure(7)
% plot(0:(length(media)-1),media)
% hold on
% plot(0:(length(mediaprim)-1),mediaprim,'r')
% title ('Comparacion de media y media prima en lugar de ataque')
% xlabel ('Segundos de la duraci�n de la trama')
% ylabel('Valores media')
% legend('media', 'mediaprima')
% hold off
