function [alfa, beta, gam, delta ] = calculo_alfa_estable__valor(signal, duracion,graficas,x, tipo,color, valor_inicio, intervalo, separacion1,separacion2 )
% Esta funcion se encarga de realizar el calculo de los valores alfa
% estable en un punto dado, con la distancia que se requiera entre
% el valor y el paso entre cada uno de ellos. Devuelve los valores
% calculados.

k=1;
for i=(valor_inicio-separacion1):intervalo:((valor_inicio+separacion2)-(duracion*60))
    
    [alfa(k),beta(k),gam(k),delta(k)]=parametrizacion_calculo_alfa_estables(signal, duracion, i, x,graficas,tipo,color );
     k=k+1;
   
end





end

