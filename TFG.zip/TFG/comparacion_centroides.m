clc;clear all;close all
addpath('C:\Users\eduur\Documents\MATLAB\TFG\Centroides');
numfiles = 10;
mydata_ataq3 = cell(1, numfiles);
mydata_ataq6 = cell(1, numfiles);
mydata_ataq9 = cell(1, numfiles);
mydata_ataq05 = cell(1, numfiles);
mydata_mixtpost6= cell(1,numfiles);
mydata_mixtpost3= cell(1,numfiles);
mydata_mixtpost9= cell(1,numfiles);
mydata_mixtpost05= cell(1,numfiles);
mydata_mixtpre3 = cell(1, numfiles);
mydata_mixtpre6= cell(1,numfiles);
mydata_mixtpre9= cell(1,numfiles);
mydata_mixtpre05= cell(1,numfiles);
mydata_norm3 = cell(1, numfiles);
mydata_norm6= cell(1,numfiles);
mydata_norm9= cell(1,numfiles);
mydata_norm05= cell(1,numfiles);
mydata_norm26 = cell(1, numfiles);
mydata_norm23= cell(1,numfiles);
mydata_norm29= cell(1,numfiles);
mydata_norm205= cell(1,numfiles);
ncentroides_ataq=80;
ncentroides_norm=10;
ncentroides_mixtpost=30;
ncentroides_mixtpre=30;
%%Cargar los archivos de los centroides:
for k = 1:numfiles
    myfilename3 = sprintf('centroid_ataq_%d_3.mat', k);
    myfilename6 = sprintf('centroid_ataq_%d_6.mat', k);
    myfilename9 = sprintf('centroid_ataq_%d_9.mat', k);
    myfilename05 = sprintf('centroid_ataq_%d_05.mat', k);
    mydata_ataq3{k} = importdata(myfilename3); 
    mydata_ataq6{k}=importdata(myfilename6);
    mydata_ataq9{k}=importdata(myfilename9);
    mydata_ataq05{k}=importdata(myfilename05);
   
end
for k = 1:numfiles
    myfilename3 = sprintf('centroid_mixtpost_%d_3.mat', k);
    myfilename6 = sprintf('centroid_mixtpost_%d_6.mat', k);
    myfilename9 = sprintf('centroid_mixtpost_%d_9.mat', k);
    myfilename05 = sprintf('centroid_mixtpost_%d_05.mat', k);
    mydata_mixtpost3{k} = importdata(myfilename3); 
    mydata_mixtpost6{k}=importdata(myfilename6);
    mydata_mixtpost9{k}=importdata(myfilename9);
    mydata_mixtpost05{k}=importdata(myfilename05);
    
   
end 
for k = 1:numfiles
    myfilename3 = sprintf('centroid_mixtpre_%d_3.mat', k);
    myfilename6 = sprintf('centroid_mixtpre_%d_6.mat', k);
    myfilename9 = sprintf('centroid_mixtpre_%d_9.mat', k);
    myfilename05 = sprintf('centroid_mixtpre_%d_05.mat', k);
    mydata_mixtpre3{k} = importdata(myfilename3); 
    mydata_mixtpre6{k}=importdata(myfilename6);
    mydata_mixtpre9{k}=importdata(myfilename9);
    mydata_mixtpre05{k}=importdata(myfilename05);
   
end 
for k = 1:numfiles
    myfilename3 = sprintf('centroid_norm_%d_3.mat', k);
    myfilename6 = sprintf('centroid_norm_%d_6.mat', k);
    myfilename9 = sprintf('centroid_mixtpost_%d_9.mat', k);
    myfilename05 = sprintf('centroid_mixtpost_%d_05.mat', k);
    mydata_norm3{k} = importdata(myfilename3); 
    mydata_norm6{k}=importdata(myfilename6);
    mydata_norm9{k}=importdata(myfilename9);
    mydata_norm05{k}=importdata(myfilename05);
end 
for k = 1:numfiles
    myfilename3 = sprintf('centroid_norm2_%d_3.mat', k);
    myfilename6 = sprintf('centroid_norm2_%d_6.mat', k);
    myfilename9 = sprintf('centroid_norm2_%d_9.mat', k);
    myfilename05 = sprintf('centroid_norm2_%d_05.mat', k);
    mydata_norm23{k} = importdata(myfilename3); 
    mydata_norm26{k}=importdata(myfilename6);
    mydata_norm29{k}=importdata(myfilename9);
    mydata_norm205{k}=importdata(myfilename05);
   
   
end

%%Plot clusters de centroides
C1 = repmat([0,0,1],1,1);
C3 = repmat([0,1,0],1,1);
C2 = repmat([1,0,0],1,1);
C = repmat([1,1,1],1,1);
C4=repmat([1,0,1],1,1);
C5=repmat([1,1, 0],1,1);
C6=repmat([0,1,0],1,1);
C7=repmat([0.5,0.2,0.5],1,1);
C8=repmat([0.85,0.32,0.12],1,1);
C9=repmat([0.6350, 0.0780, 0.1840],1,1);
color_matrix=[C;C1;C2;C3;C4;C5;C6;C7;C8;C9];
%color_matrix=['r';'y';'c';'m';'b';'g';'k';;'g';'y'];

figure;
for k=1:numfiles
    a= mydata_ataq3{k};
    for i=1:ncentroides_ataq
     
   
     scatter3(a(i,1),a(i,2),a(i,3),50,color_matrix(k,:));
     hold on
    end
end
title('Ataque situado en el 30% del segmento');
xlabel('alfa');
zlabel('gamma');
ylabel('delta');
figure;
for k=1:numfiles
    b= mydata_ataq6{k};
    for i=1:ncentroides_ataq
     
   
     scatter3(b(i,1),b(i,2),b(i,3),50,color_matrix(k,:));
     hold on
    end
end
title('Ataque situado en el 60% del segmento');
xlabel('alfa');
zlabel('gamma');
ylabel ('delta');
figure;
for k=1:numfiles
    c= mydata_ataq9{k};
    for i=1:ncentroides_ataq
     
   
     scatter3(c(i,1),c(i,2),c(i,3),50,color_matrix(k,:));
     hold on
    end
end
title('Ataque situado en el 90% del segmento');
xlabel('alfa');
zlabel('gamma');
ylabel ('delta');
figure;
for k=1:numfiles
    d= mydata_ataq05{k};
    for i=1:ncentroides_ataq
     
   
     scatter3(d(i,1),d(i,2),d(i,3),50,color_matrix(k,:));
     hold on
    end
end
title('Ataque situado en el 5% del segmento');
xlabel('alfa');
zlabel('gamma');
ylabel ('delta');

for x=1:numfiles  
     a= mydata_ataq05{x};
     b= mydata_ataq3{x};
     c=mydata_ataq6{x};
     d=mydata_ataq9{x};
    figure;
    for i=1:ncentroides_ataq

   
     scatter3(d(i,1),d(i,2),d(i,3),50,'r');
     hold on;
     scatter3(c(i,1),c(i,2),c(i,3),50,'r');
     hold on;
     scatter3(b(i,1),b(i,2),b(i,3),50,'r');
     hold on;
     scatter3(a(i,1),a(i,2),a(i,3),50,'r');
     %legend([{'Ataque en 90%'},{'Ataque en 60%'},{'Ataque en 30%'},{'Ataque en 0.5%'}]);
    end
     for i=1:ncentroides_norm
     e= mydata_norm3{x};
     f=mydata_norm6{x};
     g=mydata_norm9{x};
     h=mydata_norm05{x};
%      p= mydata_norm23{x};
%      o=mydata_norm26{x};
%      q=mydata_norm29{x};
%      r=mydata_norm205{x};
   
     scatter3(e(i,1),e(i,2),e(i,3),50,'g');
     hold on;
     scatter3(f(i,1),f(i,2),f(i,3),50,'g');
     hold on;
     scatter3(g(i,1),g(i,2),g(i,3),50,'g');
     hold on;
     scatter3(h(i,1),h(i,2),h(i,3),50,'g');
     hold on
     xlabel('alfa');
zlabel('gamma');
ylabel ('delta');
%      scatter3(o(i,1),o(i,2),o(i,3),50,'g');
%      hold on;
%      scatter3(p(i,1),p(i,2),p(i,3),50,'g');
%      hold on;
%      scatter3(q(i,1),q(i,2),q(i,3),50,'g');
%      hold on;
%      scatter3(r(i,1),r(i,2),r(i,3),50,'g');
%      hold on
     
    end
     
    end
    

figure;

for k=1:numfiles   
     a= mydata_mixtpost3{k};
     b=mydata_mixtpost6{k};
     c=mydata_mixtpost9{k};
     d=mydata_mixtpost05{k};
    for i=1:ncentroides_mixtpost

     scatter3(a(i,1),a(i,2),a(i,3),50,'r');
     hold on
     scatter3(b(i,1),b(i,2),b(i,3),50,'g');
     hold on
     scatter3(c(i,1),c(i,2),c(i,3),50,'c');
     hold on
     scatter3(d(i,1),d(i,2),d(i,3),50,'k');
     hold on
    end
end
title('Trafico mixto post ataque en disntos punto del segmento');
figure;

for k=1:numfiles  
    a= mydata_mixtpre3{k};
     b=mydata_mixtpre6{k};
     c=mydata_mixtpre9{k};
     d=mydata_mixtpre05{k};
    for i=1:ncentroides_mixtpre

     scatter3(a(i,1),a(i,2),a(i,3),50,'r');
     hold on
     scatter3(b(i,1),b(i,2),b(i,3),50,'g');
     hold on
     scatter3(c(i,1),c(i,2),c(i,3),50,'c');
     hold on
     scatter3(d(i,1),d(i,2),d(i,3),50,'k');
     hold on
    end
end
title('Trafico mixto pre ataque en disntos punto del segmento');
figure;

for k=1:numfiles   
     a= mydata_norm3{k};
     b=mydata_norm6{k};
     c=mydata_norm9{k};
     d=mydata_norm05{k};
    for i=1:ncentroides_norm

     scatter3(a(i,1),a(i,2),a(i,3),50,'r');
     hold on
     scatter3(b(i,1),b(i,2),b(i,3),50,'g');
     hold on
     scatter3(c(i,1),c(i,2),c(i,3),50,'c');
     hold on
     scatter3(d(i,1),d(i,2),d(i,3),50,'k');
     hold on
    end
end
title('Trafico normal pre ataque en disntos punto del segmento');
figure;
for k=1:numfiles
     a= mydata_norm23{k};
     b=mydata_norm26{k};
     c=mydata_norm29{k};
     d=mydata_norm205{k};
    for i=1:ncentroides_norm

     
     scatter3(a(i,1),a(i,2),a(i,3),50,'r');
     hold on
     scatter3(b(i,1),b(i,2),b(i,3),50,'g');
     hold on
     scatter3(c(i,1),c(i,2),c(i,3),50,'c');
     hold on
     scatter3(d(i,1),d(i,2),d(i,3),50,'k');
     hold on
    end
end
title('Trafico normal post ataque en disntos punto del segmento');
figure;
for k=1:numfiles
     a= mydata_ataq3{k};
     b=mydata_ataq6{k};
     c=mydata_ataq9{k};
     d=mydata_ataq05{k};
    for i=1:ncentroides_ataq
   
    
     scatter3(a(i,1),a(i,2),a(i,3),50,'r');
     hold on
     scatter3(b(i,1),b(i,2),b(i,3),50,'g');
     hold on
     scatter3(c(i,1),c(i,2),c(i,3),50,'c');
     hold on     
     scatter3(d(i,1),d(i,2),d(i,3),50,'m');
     hold on
     
    end
end
title('Ataque en disntos punto del segmento');



