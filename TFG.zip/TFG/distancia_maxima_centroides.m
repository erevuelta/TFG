
    
d_max1= load('C:\Users\eduur\Documents\MATLAB\TFG\Centroides\d_max_ataq1.mat');
d_max12= load('C:\Users\eduur\Documents\MATLAB\TFG\Centroides\d_max_ataq12.mat');
d_max2= load('C:\Users\eduur\Documents\MATLAB\TFG\Centroides\d_max_ataq2.mat');
d_max22= load('C:\Users\eduur\Documents\MATLAB\TFG\Centroides\d_max_ataq22.mat');
d_max3= load('C:\Users\eduur\Documents\MATLAB\TFG\Centroides\d_max_ataq3.mat');
d_max32= load('C:\Users\eduur\Documents\MATLAB\TFG\Centroides\d_max_ataq32.mat');
d_max4= load('C:\Users\eduur\Documents\MATLAB\TFG\Centroides\d_max_ataq4.mat');
d_max42= load('C:\Users\eduur\Documents\MATLAB\TFG\Centroides\d_max_ataq42.mat');
d_max5= load('C:\Users\eduur\Documents\MATLAB\TFG\Centroides\d_max_ataq5.mat');
d_max52= load('C:\Users\eduur\Documents\MATLAB\TFG\Centroides\d_max_ataq52.mat');
d_max6= load('C:\Users\eduur\Documents\MATLAB\TFG\Centroides\d_max_ataq6.mat');
d_max62= load('C:\Users\eduur\Documents\MATLAB\TFG\Centroides\d_max_ataq62.mat');
d_max7= load('C:\Users\eduur\Documents\MATLAB\TFG\Centroides\d_max_ataq7.mat');
d_max72= load('C:\Users\eduur\Documents\MATLAB\TFG\Centroides\d_max_ataq72.mat');
d_max8= load('C:\Users\eduur\Documents\MATLAB\TFG\Centroides\d_max_ataq8.mat');
d_max82= load('C:\Users\eduur\Documents\MATLAB\TFG\Centroides\d_max_ataq82.mat');
d_max9= load('C:\Users\eduur\Documents\MATLAB\TFG\Centroides\d_max_ataq9.mat');
d_max92= load('C:\Users\eduur\Documents\MATLAB\TFG\Centroides\d_max_ataq92.mat');
d_max10= load('C:\Users\eduur\Documents\MATLAB\TFG\Centroides\d_max_ataq10.mat');
d_max102= load('C:\Users\eduur\Documents\MATLAB\TFG\Centroides\d_max_ataq102.mat');

d_max1=min(d_max1.d_max_ataq);
d_max12=min(d_max12.d_max_ataq);
d_max2=min(d_max2.d_max_ataq);
d_max22=min(d_max22.d_max_ataq);
d_max3=min(d_max3.d_max_ataq);
d_max32=min(d_max32.d_max_ataq);
d_max4=min(d_max4.d_max_ataq);
d_max42=min(d_max42.d_max_ataq);
d_max5=min(d_max5.d_max_ataq);
d_max52=min(d_max52.d_max_ataq);
d_max6=min(d_max6.d_max_ataq);
d_max62=min(d_max62.d_max_ataq);
d_max7=min(d_max7.d_max_ataq);
d_max72=min(d_max72.d_max_ataq);
d_max8=min(d_max8.d_max_ataq);
d_max82=min(d_max82.d_max_ataq);
d_max9=min(d_max9.d_max_ataq);
d_max92=min(d_max92.d_max_ataq);
d_max10=min(d_max10.d_max_ataq);
d_max102=min(d_max102.d_max_ataq);
d1=min(round(d_max1),round(d_max12));
d2=min(round(d_max2),round(d_max22));
d3=min(round(d_max3),round(d_max32));
d4=min(round(d_max4),round(d_max42));
d5=min(round(d_max5),round(d_max52));
d6=min(round(d_max6),round(d_max62));
d7=min(round(d_max7),round(d_max72));
d8=min(round(d_max8),round(d_max82));
d9=min(round(d_max9),round(d_max92));
d10=min(round(d_max10),round(d_max102));
d=[d1;d2;d3;d4;d5;d6;d7;d8;d9;d10];
d=min(d);
d=d/(2*d_max1);


