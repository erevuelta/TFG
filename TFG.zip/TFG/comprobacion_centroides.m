
clc;close all;
addpath('C:\Users\eduur\Documents\MATLAB\TFG\eric');
addpath('C:\Users\eduur\Documents\MATLAB\TFG\stbl-master');
addpath('C:\Users\eduur\Documents\MATLAB\TFG\Centroides_comprob');
dbstop if error;
load('ancho_banda_pkt2.txt')

load('ab_pkt2_ddos_puro.txt')


alfa=[];
beta=[];
gam=[];
delta=[];

t0=round(605181/2);
numfiles = 10;

clase_predict1={};
clase_predict2={};
clase_predict3={};
clase_predict4={};
clase_predict5={};
clase_predict6={};
clase_predict7={};
clase_predict8={};
clase_predict9={};
clase_predict10={};

clase_true1={'normal'};
clase_true=repmat(clase_true1,60218,1);
clase_ataq={'ataque'};
clase_ataq=repmat(clase_ataq,2169,1);
clase_resto=repmat(clase_true1,(60218-2169),1);
clase_ataq= [clase_ataq' clase_resto'];

mydata_ataq3 = cell(1, numfiles);
mydata_ataq6 = cell(1, numfiles);
mydata_mixtpost6= cell(1,numfiles);
mydata_mixtpost3= cell(1,numfiles);
mydata_mixtpre3 = cell(1, numfiles);
mydata_mixtpre6= cell(1,numfiles);
mydata_norm3 = cell(1, numfiles);
mydata_norm6= cell(1,numfiles);
mydata_norm26 = cell(1, numfiles);
mydata_norm23= cell(1,numfiles);

ncentroides_ataq=80;
ncentroides_norm=10;
ncentroides_mixtpost=30;
ncentroides_mixtpre=30;

traf_mezcla=mezclar_trafico(ancho_banda_pkt2,ab_pkt2_ddos_puro,t0);
len=length(traf_mezcla);

traf=struct;
alfa_tot=struct;
beta_tot=struct;
gam_tot=struct;
delta_tot=struct;

%%Cargar los archivos de los centroides:
for k = 1:numfiles
    myfilename3 = sprintf('centroid_norm_%d_c.mat', k);
    mydata_norm{k} = importdata(myfilename3);
    
   
end
for k = 5
    myfilename3 = sprintf('centroid_mixtpost_%d_c.mat', k);
    mydata_mixtpost{k} = importdata(myfilename3); 
    
   
end 
for k = 5
    myfilename3 = sprintf('centroid_mixtpre_%d_c.mat', k);
    mydata_mixtpre{k} = importdata(myfilename3); 
    
end 
for k = 5
    myfilename3 = sprintf('centroid_ataq_%d_c.mat', k);
    mydata_ataq{k} = importdata(myfilename3); 
   
end 
for k = 5
    myfilename3 = sprintf('centroid_norm2_%d_c.mat', k);
    mydata_norm2{k} = importdata(myfilename3); 
   
end
figure;

     a= mydata_ataq{5};
    
     for x=1:numfiles
     d=mydata_norm{x}; 
     
          for i=1:ncentroides_norm
             h1=scatter3(d(i,1),d(i,2),d(i,3),50,'g');
             hold on
     
          end
     end
     for i=1:ncentroides_ataq
        h2= scatter3(a(i,1),a(i,2),a(i,3),50,'r');
     end
     legend
     title('Centroides del tr�fico completo con ataque en la mitad');
     legend([h1,h2],'Normal','Ataque')
     xlabel('Alpha');
     ylabel('Delta');
     zlabel('Gamma');
 
     
     
     
     
     
     
     
     
     
     
     
     
     
     
%     for i=1:numfiles
%         traf.(sprintf('a%d',i))=traf_mezcla((len.*(i-1)/10)+1:(len.*i/10),1:2);
%     end
%     
% for i=1:numfiles 
%      type_dist='squaredeuclidean';
%     tw0=1;
%     tw1=(5*60);
%     t0=round(605181/2);
%     
%     alfa=zeros(1,round((len/10)-(tw1-tw0+1)),'double');
%     beta=zeros(1,round((len/10)-(tw1-tw0+1)),'double');
%     gam=zeros(1,round((len/10)-(tw1-tw0+1)),'double');
%     delta=zeros(1,round((len/10)-(tw1-tw0+1)),'double');
%     
%    
% for tw0=1:1:((len/10)-(tw1-tw0+1))
% 
%     
%     signal=traf.(sprintf('a%d',i))(tw0:tw1,1:2);
%     [alfaprim, betaprim, gamprim, deltaprim ] = parametrizacion_calculo_alfa_estables_prueba(signal);
%     
%     alfa(tw0)=alfaprim;
%     beta(tw0)=betaprim;
%     gam(tw0)=gamprim;
%     delta(tw0)=deltaprim;
%     tw1=tw1+1;
% end
% 
%     alfa_tot.(sprintf('a%d',i))=alfa;
%     delta_tot.(sprintf('a%d',i))=delta;
%     gam_tot.(sprintf('a%d',i))=gam;
%     beta_tot.(sprintf('a%d',i))=beta;
%     
% end
% for i=1:numfiles
%     centroid3_ataq{i}=mydata_ataq3{1,i};
%     centroid6_ataq{i}=mydata_ataq6{1,i};
% end
% 
% centroids1=[centroid3_ataq{1}' centroid6_ataq{1}']';
% centroids2=[centroid3_ataq{2}' centroid6_ataq{2}']';
% centroids3=[centroid3_ataq{3}' centroid6_ataq{3}']';
% centroids4=[centroid3_ataq{4}' centroid6_ataq{4}']';
% centroids5=[centroid3_ataq{5}' centroid6_ataq{5}']';
% centroids6=[centroid3_ataq{6}' centroid6_ataq{6}']';
% centroids7=[centroid3_ataq{7}' centroid6_ataq{7}']';
% centroids8=[centroid3_ataq{8}' centroid6_ataq{8}']';
% centroids9=[centroid3_ataq{9}' centroid6_ataq{9}']';
% centroids10=[centroid3_ataq{10}' centroid6_ataq{10}']';
% 
% centroids1(:,2)=centroids1(:,2)./max(delta_tot.a1);
% centroids2(:,2)=centroids2(:,2)./max(delta_tot.a2);
% centroids3(:,2)=centroids3(:,2)./max(delta_tot.a3);
% centroids4(:,2)=centroids4(:,2)./max(delta_tot.a4);
% centroids5(:,2)=centroids5(:,2)./max(delta_tot.a5);
% centroids6(:,2)=centroids6(:,2)./max(delta_tot.a6);
% centroids7(:,2)=centroids7(:,2)./max(delta_tot.a7);
% centroids8(:,2)=centroids8(:,2)./max(delta_tot.a8);
% centroids9(:,2)=centroids9(:,2)./max(delta_tot.a9);
% centroids10(:,2)=centroids10(:,2)./max(delta_tot.a10);
% 
% centroids1(:,3)=centroids1(:,3)./max(gam_tot.a1);
% centroids2(:,3)=centroids2(:,3)./max(gam_tot.a2);
% centroids3(:,3)=centroids3(:,3)./max(gam_tot.a3);
% centroids4(:,3)=centroids4(:,3)./max(gam_tot.a4);
% centroids5(:,3)=centroids5(:,3)./max(gam_tot.a5);
% centroids6(:,3)=centroids6(:,3)./max(gam_tot.a6);
% centroids7(:,3)=centroids7(:,3)./max(gam_tot.a7);
% centroids8(:,3)=centroids8(:,3)./max(gam_tot.a8);
% centroids9(:,3)=centroids9(:,3)./max(gam_tot.a9);
% centroids10(:,3)=centroids10(:,3)./max(gam_tot.a10);
% 
% delta_tot.a1=delta_tot.a1./max(delta_tot.a1);
% delta_tot.a2=delta_tot.a2./max(delta_tot.a2);
% delta_tot.a3=delta_tot.a3./max(delta_tot.a3);
% delta_tot.a4=delta_tot.a4./max(delta_tot.a4);
% delta_tot.a5=delta_tot.a5./max(delta_tot.a5);
% delta_tot.a6=delta_tot.a6./max(delta_tot.a6);
% delta_tot.a7=delta_tot.a7./max(delta_tot.a7);
% delta_tot.a8=delta_tot.a8./max(delta_tot.a8);
% delta_tot.a9=delta_tot.a9./max(delta_tot.a9);
% delta_tot.a10=delta_tot.a10./max(delta_tot.a10);
% 
% gam_tot.a1=gam_tot.a1./max(gam_tot.a1);
% gam_tot.a2=gam_tot.a2./max(gam_tot.a2);
% gam_tot.a3=gam_tot.a3./max(gam_tot.a3);
% gam_tot.a4=gam_tot.a4./max(gam_tot.a4);
% gam_tot.a5=gam_tot.a5./max(gam_tot.a5);
% gam_tot.a6=gam_tot.a6./max(gam_tot.a6);
% gam_tot.a7=gam_tot.a7./max(gam_tot.a7);
% gam_tot.a8=gam_tot.a8./max(gam_tot.a8);
% gam_tot.a9=gam_tot.a9./max(gam_tot.a9);
% gam_tot.a10=gam_tot.a10./max(gam_tot.a10);
% 
% for i=1:numfiles
% datos_all.(sprintf('a%d',i))=[alfa_tot.(sprintf('a%d',i)); delta_tot.(sprintf('a%d',i)); gam_tot.(sprintf('a%d',i)); beta_tot.(sprintf('a%d',i))]';
% end
% 
% d_ataq1= pdist2(datos_all.(sprintf('a%d',1))(:,[1 2 3]),centroids1,type_dist);
% d_ataq2= pdist2(datos_all.(sprintf('a%d',2))(:,[1 2 3]),centroids2,type_dist);
% d_ataq3= pdist2(datos_all.(sprintf('a%d',3))(:,[1 2 3]),centroids3,type_dist);
% d_ataq4= pdist2(datos_all.(sprintf('a%d',4))(:,[1 2 3]),centroids4,type_dist);
% d_ataq5= pdist2(datos_all.(sprintf('a%d',5))(:,[1 2 3]),centroids5,type_dist);
% d_ataq6= pdist2(datos_all.(sprintf('a%d',6))(:,[1 2 3]),centroids6,type_dist);
% d_ataq7= pdist2(datos_all.(sprintf('a%d',7))(:,[1 2 3]),centroids7,type_dist);
% d_ataq8= pdist2(datos_all.(sprintf('a%d',8))(:,[1 2 3]),centroids8,type_dist);
% d_ataq9= pdist2(datos_all.(sprintf('a%d',9))(:,[1 2 3]),centroids9,type_dist);
% d_ataq10= pdist2(datos_all.(sprintf('a%d',10))(:,[1 2 3]),centroids10,type_dist);
% 
% for k=1:length(d_ataq1)
%     d1=min(d_ataq1(k,:));
%     if d1<4.595390825337895e-04
%         clase_predict1{k}='ataque';
%     else
%         clase_predict1{k}='normal';
%         
%     end
% end
% for k=1:length(d_ataq2)
%     d2=min(d_ataq2(k,:));
%     if d2<9.190781650675790e-04
%         clase_predict2{k}='ataque';
%     else
%         clase_predict2{k}='normal';
%         
%     end
% end
% for k=1:length(d_ataq3)
%     d3=min(d_ataq3(k,:));
%     if d3<9.190781650675790e-04
%         clase_predict3{k}='ataque';
%     else
%         clase_predict3{k}='normal';
%         
%     end
% end
% for k=1:length(d_ataq4)
%     d4=min(d_ataq4(k,:));
%     if d4<9.190781650675790e-04
%         clase_predict4{k}='ataque';
%     else
%         clase_predict4{k}='normal';
%         
%     end
% end
% for k=1:length(d_ataq5)
%     d5=min(d_ataq5(k,:));
%     if d5<4.595390825337895e-04
%         clase_predict5{k}='ataque';
%     else
%         clase_predict5{k}='normal';
%         
%     end
% end
% for k=1:length(d_ataq6)
%     d6=min(d_ataq6(k,:));
%     if d6<9.190781650675790e-04
%         clase_predict6{k}='ataque';
%     else
%         clase_predict6{k}='normal';
%         
%     end
% end
% for k=1:length(d_ataq7)
%     d7=min(d_ataq7(k,:));
%     if d7<d_max_ataq(:)
%         clase_predict7{k}='ataque';
%     else
%         clase_predict7{k}='normal';
%         
%     end
% end
% for k=1:length(d_ataq8)
%     d8=min(d_ataq8(k,:));
%     if d8<d_max_ataq(:)
%         clase_predict8{k}='ataque';
%     else
%         clase_predict8{k}='normal';
%         
%     end
% end
% for k=1:length(d_ataq9)
%     d9=min(d_ataq9(k,:));
%     if d9<d_max_ataq(:)
%         clase_predict9{k}='ataque';
%     else
%         clase_predict9{k}='normal';
%         
%     end
% end
% for k=1:length(d_ataq10)
%     d10=min(d_ataq10(k,:)./4);
%     if d10<d_max_ataq(:)
%         clase_predict10{k}='ataque';
%     else
%         clase_predict10{k}='normal';
%         
%     end
% end
% 
% figure;
% MatrizAlfaGammaDelta = confusionchart(clase_true,clase_predict1, 'RowSummary','row-normalized','ColumnSummary','column-normalized');
% figure;
% MatrizAlfaGammaDelta = confusionchart(clase_true,clase_predict2, 'RowSummary','row-normalized','ColumnSummary','column-normalized');
% figure;
% MatrizAlfaGammaDelta = confusionchart(clase_true,clase_predict3, 'RowSummary','row-normalized','ColumnSummary','column-normalized');
% figure;
% MatrizAlfaGammaDelta = confusionchart(clase_true,clase_predict4, 'RowSummary','row-normalized','ColumnSummary','column-normalized');
% figure;
% MatrizAlfaGammaDelta = confusionchart(clase_ataq,clase_predict5, 'RowSummary','row-normalized','ColumnSummary','column-normalized');
% figure;
% MatrizAlfaGammaDelta = confusionchart(clase_true,clase_predict6, 'RowSummary','row-normalized','ColumnSummary','column-normalized');
% figure;
% MatrizAlfaGammaDelta = confusionchart(clase_true,clase_predict7, 'RowSummary','row-normalized','ColumnSummary','column-normalized');
% figure;
% MatrizAlfaGammaDelta = confusionchart(clase_true,clase_predict8, 'RowSummary','row-normalized','ColumnSummary','column-normalized');
% figure;
% MatrizAlfaGammaDelta = confusionchart(clase_true,clase_predict9, 'RowSummary','row-normalized','ColumnSummary','column-normalized');
% figure;
% MatrizAlfaGammaDelta = confusionchart(clase_true,clase_predict10, 'RowSummary','row-normalized','ColumnSummary','column-normalized');
% 
% figure;
%  scatter3(datos_all.(sprintf('a%d',1))(:,1),datos_all.(sprintf('a%d',1))(:,2),datos_all.(sprintf('a%d',1))(:,3), 20, 'go');
% for i=1:length(centroids5)/2
%       
%        scatter3(centroids5(i,1),centroids5(i,2),centroids5(i,3),300,'gx','LineWidth',3)
%        hold on
% 
% end
% for i=length(centroids5)/2:length(centroids5)
%       
%        scatter3(centroids5(i,1),centroids5(i,2),centroids5(i,3),300,'rx','LineWidth',3)
%        hold on
% 
% end
% figure;
% scatter3(datos_all.(sprintf('a%d',2))(:,1),datos_all.(sprintf('a%d',2))(:,2),datos_all.(sprintf('a%d',2))(:,3), 20, 'go');
% for i=1:length(centroids1)
%        hold on
%        scatter3(centroids2(i,1),centroids2(i,2),centroids2(i,3),300,'kx','LineWidth',3)
% 
% end
% figure;
% scatter3(datos_all.(sprintf('a%d',3))(:,1),datos_all.(sprintf('a%d',3))(:,2),datos_all.(sprintf('a%d',3))(:,3), 20, 'go');
% for i=1:length(centroids1)
%        hold on
%        scatter3(centroids3(i,1),centroids3(i,2),centroids3(i,3),300,'kx','LineWidth',3)
% 
% end
% figure;
% scatter3(datos_all.(sprintf('a%d',1))(:,1),datos_all.(sprintf('a%d',1))(:,2),datos_all.(sprintf('a%d',1))(:,3), 20, 'go');
% for i=1:length(centroids1)
%        hold on
%        scatter3(centroids1(i,1),centroids1(i,2),centroids1(i,3),300,'kx','LineWidth',3)
% 
% end
% figure;
% scatter3(datos_all.(sprintf('a%d',4))(:,1),datos_all.(sprintf('a%d',4))(:,2),datos_all.(sprintf('a%d',4))(:,3), 20, 'go');
% for i=1:length(centroids1)
%        hold on
%        scatter3(centroids4(i,1),centroids4(i,2),centroids4(i,3),300,'kx','LineWidth',3)
% 
% end
% figure;
% scatter3(datos_all.(sprintf('a%d',5))(:,1),datos_all.(sprintf('a%d',5))(:,2),datos_all.(sprintf('a%d',5))(:,3), 20, 'go');
% for i=1:length(centroids1)
%        hold on
%        scatter3(centroids5(i,1),centroids5(i,2),centroids5(i,3),300,'kx','LineWidth',3)
% 
% end
% figure;
% scatter3(datos_all.(sprintf('a%d',6))(:,1),datos_all.(sprintf('a%d',6))(:,2),datos_all.(sprintf('a%d',6))(:,3), 20, 'go');
% for i=1:length(centroids1)
%        hold on
%        scatter3(centroids6(i,1),centroids6(i,2),centroids6(i,3),300,'kx','LineWidth',3)
% 
% end
%        figure;
% scatter3(datos_all.(sprintf('a%d',7))(:,1),datos_all.(sprintf('a%d',7))(:,2),datos_all.(sprintf('a%d',7))(:,3), 20, 'go');
% for i=1:length(centroids1)
%        hold on
%        scatter3(centroids7(i,1),centroids7(i,2),centroids7(i,3),300,'kx','LineWidth',3)
% 
% end
% figure;
% scatter3(datos_all.(sprintf('a%d',8))(:,1),datos_all.(sprintf('a%d',8))(:,2),datos_all.(sprintf('a%d',8))(:,3), 20, 'go');
% for i=1:length(centroids1)
%        hold on
%        scatter3(centroids8(i,1),centroids8(i,2),centroids8(i,3),300,'kx','LineWidth',3)
% 
% end
% figure;
% scatter3(datos_all.(sprintf('a%d',9))(:,1),datos_all.(sprintf('a%d',9))(:,2),datos_all.(sprintf('a%d',9))(:,3), 20, 'go');
% for i=1:length(centroids1)
%        hold on
%        scatter3(centroids9(i,1),centroids9(i,2),centroids9(i,3),300,'kx','LineWidth',3)
% 
% end
% figure;
% scatter3(datos_all.(sprintf('a%d',10))(:,1),datos_all.(sprintf('a%d',10))(:,2),datos_all.(sprintf('a%d',10))(:,3), 20, 'go');
% for i=1:length(centroids1)
%        hold on
%        scatter3(centroids10(i,1),centroids10(i,2),centroids10(i,3),300,'kx','LineWidth',3)
% 
% end
