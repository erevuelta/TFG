clc;
clear all;
close all;

addpath('C:\Users\eduur\Documents\MATLAB\TFG\Datos');

%datos originales
load('gam_5min.mat');
load('delta_5min.mat');
load('beta_5min.mat');
load('alfa_5min.mat');
load('alfaprim_5min.mat');
load('betaprim_5min.mat');
load('gamprim_5min.mat');
load('deltaprim_5min.mat');

%ventana original
normpre=6800;
normmixt=6862;
mixtataq=7018;
ataqmixt=7198;
mixtnorm=7354;
normpost=7400;
norm_pre=normpre:normmixt;
mix_pre=normmixt:mixtataq;
attack=mixtataq:ataqmixt;
mix_post=ataqmixt:mixtnorm;
norm_post= mixtnorm:normpost;


%series_temporales(alfa, beta, delta, gam, alfaprim, betaprim, deltaprim, gamprim, mix_pre, attack, mix_post);

%representacion_parametros (alfa, beta, gam, delta, alfaprim, betaprim, gamprim, deltaprim, mix_pre, attack, mix_post);

clusterizacion(alfaprim, betaprim, deltaprim, gamprim, normpre, normmixt,mixtataq,ataqmixt,mixtnorm,normpost);


%Centroide
% ncentroides_norm=10;
% ncentroides_mixtpre=30;
% ncentroides_mixtpost=30;
% ncentroides_ataq=80;
% type_dist='squaredeuclidean';%'euclidean'; %'mahalanobis'; 'euclidean'; 'squaredeuclidean'; 'hamming'; 'cityblock'
% tw0= 1;
% tw1=(5*60); %Ventana de 5 minutos
% t0=round((605181/100)*80);    %6300;
% t1=2169+t0;     %length(ddos)         %7400;
% fin_trafico=round((605181/10)*8);

% [C_norm,C_mixtpre,C_mixtpost,C_ataq,C_norm2] = centroids(tw0,tw1,t0,t1,ncentroides_norm,ncentroides_mixtpre,ncentroides_mixtpost,ncentroides_ataq,type_dist,fin_trafico);
% 
% save('C:\Users\eduur\Documents\MATLAB\TFG\Centroides\centroid_norm_1_05.mat', 'C_norm');
% save('C:\Users\eduur\Documents\MATLAB\TFG\Centroides\centroid_mixtpre_1_05.mat', 'C_mixtpre');
% save('C:\Users\eduur\Documents\MATLAB\TFG\Centroides\centroid_mixtpost_1_05.mat', 'C_mixtpost');
% save('C:\Users\eduur\Documents\MATLAB\TFG\Centroides\centroid_ataq_1_05.mat', 'C_ataq');
% save('C:\Users\eduur\Documents\MATLAB\TFG\Centroides\centroid_norm2_1_05.mat', 'C_norm2');
% save('C:\Users\eduur\Documents\MATLAB\TFG\Centroides\d_max_ataq102.mat', 'd_max_ataq');

%%Codigo comprobacion

% [C_norm,C_mixtpre,C_mixtpost,C_ataq,C_norm2] = centroids_comprob(tw0,tw1,t0,t1,ncentroides_norm,ncentroides_mixtpre,ncentroides_mixtpost,ncentroides_ataq,type_dist,fin_trafico);
% 
% save('C:\Users\eduur\Documents\MATLAB\TFG\Centroides_comprob\centroid_norm_8_c2.mat', 'C_norm');
% save('C:\Users\eduur\Documents\MATLAB\TFG\Centroides_comprob\centroid_mixtpre_8_c2.mat', 'C_mixtpre');
% save('C:\Users\eduur\Documents\MATLAB\TFG\Centroides_comprob\centroid_mixtpost_8_c2.mat', 'C_mixtpost');
% save('C:\Users\eduur\Documents\MATLAB\TFG\Centroides_comprob\centroid_ataq_8_c2.mat', 'C_ataq');
% save('C:\Users\eduur\Documents\MATLAB\TFG\Centroides_comprob\centroid_norm2_8_c2.mat', 'C_norm2');


%% H O L T W I N T E R S 
% datos= [alfaprim(normpre:(normpost-1)); deltaprim(normpre:(normpost-1)); gamprim(normpre:(normpost-1)); betaprim(normpre:(normpost-1))]';
% s=7;
% param=[0.666 0.022 0.988];
% [mae,fx]=holtwinters2(param,s,datos(:,[1 2 3]));
% figure;
% plot(fx);

