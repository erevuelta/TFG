function [alfaprim,deltaprim,gamprim,betaprim,alfa,delta,gam,beta]=generar_alfaestables(ventana_separacion)

addpath('C:\Users\eduur\Documents\MATLAB\TFG\eric');
addpath('C:\Users\eduur\Documents\MATLAB\TFG\stbl-master');

%% lectura de los ficheros normales (segundos | paquetes)

load('ancho_banda_pkt2.txt')

% lectura de los ficheros anomalos puros (segundos | paquetes)

load('ab_pkt2_ddos_puro.txt')


ab2_pkt_mezclad_ddos_ord = mezclar_trafico(ancho_banda_pkt2,ab_pkt2_ddos_puro,ventana_separacion);
figure;
plot(ancho_banda_pkt2(:,1),ancho_banda_pkt2(:,2),'b');
hold on
plot(ab2_pkt_mezclad_ddos_ord(:,1),ab2_pkt_mezclad_ddos_ord(:,2),'r');
hold off

% x = 200e6:10000:1000e+6;
x2=2e4:100:20e4;

% num_valor=300;
% 
% tam=length(ancho_banda_pkt2);

valores=[]; %posiciones de maximos se tienen que pasar a valores de tiempo para buscar en el tr�fico mezlcado
valores_m=[];

valores(1)=find( 1960==ab_pkt2_ddos_puro(:,2));
valores(2)=find( 2092==ab_pkt2_ddos_puro(:,2));
valores(3)=find(max(ab_pkt2_ddos_puro(:,2))==ab_pkt2_ddos_puro(:,2));

valores_m(1)=find(ab_pkt2_ddos_puro(valores(1),1) == ab2_pkt_mezclad_ddos_ord(:,1));
valores_m(2)=find(ab_pkt2_ddos_puro(valores(2),1) == ab2_pkt_mezclad_ddos_ord(:,1));
valores_m(3)=find(ab_pkt2_ddos_puro(valores(3),1) == ab2_pkt_mezclad_ddos_ord(:,1));

separacion=3600*2;
graficas=0;
intervalo=1;
duracion=5;

len=length(ab_pkt2_ddos_puro(:,2));
v=find(max(ab_pkt2_ddos_puro(:,2))==ab_pkt2_ddos_puro(:,2));
array_15_ddos_puro=zeros(1,15*60);
for i=1:(len-v)
    array_15_ddos_puro(i)=ab_pkt2_ddos_puro(i+v-1,2);
end

%gamma es sigma y delta es mu
[alfa, beta, gam, delta] = calculo_alfa_estable__valor(ancho_banda_pkt2, duracion,graficas,x2, 'Paquetes','b', valores_m(3), intervalo, separacion,separacion);

[alfaprim, betaprim, gamprim, deltaprim] = calculo_alfa_estable__valor(ab2_pkt_mezclad_ddos_ord, duracion,graficas,x2, 'Paquetes','r', valores_m(3), intervalo, separacion,separacion);

