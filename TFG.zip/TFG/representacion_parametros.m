function representacion_parametros (alfa, beta, gam, delta, alfaprim, betaprim, gamprim, deltaprim, mix_pre, attack, mix_post)

figure;
plot(alfa(6800:7400), beta(6800:7400), 'go');
hold on
plot(alfaprim(mix_pre), betaprim(mix_pre), 'kx');
hold on
plot(alfaprim(attack), betaprim(attack), 'ro');
hold on
plot(alfaprim(mix_post), betaprim(mix_post), 'b+');

xlabel('alfa');
ylabel('beta');
legend('Normal','Mixto pre-ataque', 'Ataque', 'Mixto post-ataque');
title('Alfa-Beta: Ventana de 5 min')
hold off

figure;
plot(alfa(6800:7400), gam(6800:7400), 'go');
hold on
plot(alfaprim(mix_pre), gamprim(mix_pre), 'kx');
hold on
plot(alfaprim(attack), gamprim(attack), 'ro');
hold on
plot(alfaprim(mix_post), gamprim(mix_post), 'b+');

xlabel('alfa');
ylabel('gamma');
legend('Normal','Mixto pre-ataque', 'Ataque', 'Mixto post-ataque');
title('Alfa-Gamma: Ventana de 5 min')
hold off

figure;

plot(alfa(6800:7400), delta(6800:7400), 'go');
hold on
plot(alfaprim(mix_pre), deltaprim(mix_pre), 'kx');
hold on
plot(alfaprim(attack), deltaprim(attack), 'ro');
hold on
plot(alfaprim(mix_post), deltaprim(mix_post), 'b+');


xlabel('alfa');
ylabel('delta');
legend('Normal','Mixto pre-ataque', 'Ataque', 'Mixto post-ataque');
title('Alfa-Delta: Ventana de 5 min')
hold off

figure;
plot(beta(6800:7400), gam(6800:7400), 'go');
hold on
plot(betaprim(mix_pre), gamprim(mix_pre), 'kx');
hold on
plot(betaprim(attack), gamprim(attack), 'ro');
hold on
plot(betaprim(mix_post), gamprim(mix_post), 'b+');

xlabel('beta');
ylabel('gamma');
legend('Normal','Mixto pre-ataque', 'Ataque', 'Mixto post-ataque');
title('Beta-Gamma: Ventana de 5 min')
hold off

figure;
plot(beta(6800:7400), delta(6800:7400), 'go');
hold on
plot(betaprim(mix_pre), deltaprim(mix_pre), 'kx');
hold on
plot(betaprim(attack), deltaprim(attack), 'ro');
hold on
plot(betaprim(mix_post), deltaprim(mix_post), 'b+');

xlabel('beta');
ylabel('delta');
legend('Normal','Mixto pre-ataque', 'Ataque', 'Mixto post-ataque');
title('Beta-Delta: Ventana de 5 min')
hold off

figure;
plot(gam(6800:7400), delta(6800:7400), 'go');
hold on
plot(gamprim(mix_pre), deltaprim(mix_pre), 'kx');
hold on
plot(gamprim(attack), deltaprim(attack), 'ro');
hold on
plot(gamprim(mix_post), deltaprim(mix_post), 'b+');

xlabel('gamma');
ylabel('delta');
legend('Normal','Mixto pre-ataque', 'Ataque', 'Mixto post-ataque');
title('Gamma-Delta: Ventana de 5 min')
hold off


end