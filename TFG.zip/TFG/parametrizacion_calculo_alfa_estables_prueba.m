function [alpha,beta,gam,delta]=parametrizacion_calculo_alfa_estables_prueba(signal)
%Esta funcion se encarga de calcular los valores de los alfa estable y de
%representarlos respecto de la se�al y de la ventana que se le pase como
%argumento. Representa la se�al que va a ser calculada, los valores de los alfa estable y el histograma de la sekal normalizada (pdf)
%.Signal es la se�al de la cual se va a calcular los valores de alfa-estable, es necesario que
%sea de dos dimensiones donde uno sea el eje que sigue y otro la variable aleatoria. La duracion de ventana se da en
%minutos y se realiza la conversion a segundos.X es el rango de valores que va a tener la representacion
%de los alfa estable

% duracion_ventana=duracion_ventana*60; %en segundos
% duracion_ventana=duracion_ventana*60/2;

% dbstop if error;
params = stblfit(signal(:,2),'percentile','Display');
% params = stblfit(signal(segundo_inicio+60:duracion_ventana+60+segundo_inicio,2),'percentile','Display');


% params = stblfit(signal(segundo_inicio-duracion_ventana:duracion_ventana+segundo_inicio,2),'percentile','Display');
% params = stblfit(signal(segundo_inicio-duracion_ventana+60:duracion_ventana+60+segundo_inicio,2),'percentile','Display');

alpha= params(1,1);
beta = params(2,1);
gam = params(3,1);
delta =params(4,1);






end
